
class TextGridError(Exception):
    pass