# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

from .._core import AudioStreamMetadata, VideoStreamMetadata
from ._audio_decoder import AudioDecoder  # noqa
from ._decoder_utils import (  # noqa
    get_nvdec_cache_capacity,
    set_cuda_backend,
    set_nvdec_cache_capacity,
)
from ._image_decoders import (  # noqa
    decode_avif,
    decode_gif,
    decode_heic,
    decode_image,
    decode_jpeg,
    decode_png,
    decode_webp,
    ImageReadMode,
)
from ._video_decoder import CpuFallbackStatus, VideoDecoder  # noqa
from ._wav_decoder import WavDecoder  # noqa

SimpleVideoDecoder = VideoDecoder
